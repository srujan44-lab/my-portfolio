# change
Firstly open cmd and run mongod .Minimize it. 
Then open vs code and open terminal and run node app.js.
Open a browser and set url as localhost:3000/.
for admin,username and password is adithya
